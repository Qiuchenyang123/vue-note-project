<template>
    <div class="article-wrap"></div>
</template>

<script>
export default {
    name: "articleDetail"
}
</script>

<style scoped>

</style>