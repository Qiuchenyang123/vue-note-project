<template>
    <div class="form-wrap basic-form-wrap">
        form-wrap
    </div>
</template>

<script>
export default {
    name: "basicForm"
}
</script>

<style scoped lang="scss">
.basic-form-wrap {

}
</style>