<template>
    <div class="recommendManageWrap">
        <a-table></a-table>
    </div>
</template>

<script>
export default {
    name: "recommendManage"
}
</script>

<style scoped>

</style>